package com.Store.openLegacyStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenLegacyStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
