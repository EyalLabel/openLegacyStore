package com.Store.openLegacyStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenLegacyStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenLegacyStoreApplication.class, args);
	}

}
